
export interface Debt {
  id: string;
  name: string;
  balance: number;
  monthlyPayment: number;
  payOff: boolean;
}

export interface CurrentHome {
  value: number;
  mortgageBalance: number;
  interestRate: number;
  termYears: number;
  taxInsuranceEstimate: number;
}

export interface NewHome {
  purchasePrice: number;
  interestRate: number;
  termYears: number;
  taxInsuranceEstimate: number;
}

export interface CalculationResult {
  currentMonthlyTotal: number;
  newMonthlyTotal: number;
  monthlySavings: number;
  equityProceeds: number;
  downPayment: number;
  newLoanAmount: number;
  debtsPaidOff: number;
}
