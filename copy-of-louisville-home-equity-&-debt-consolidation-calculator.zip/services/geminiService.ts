
import { GoogleGenAI } from "@google/genai";
import { CalculationResult, CurrentHome, NewHome, Debt } from "../types";

export const getAIAnalysis = async (
  current: CurrentHome,
  newH: NewHome,
  debts: Debt[],
  result: CalculationResult
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const paidDebts = debts.filter(d => d.payOff);
  const totalDebtPaid = paidDebts.reduce((acc, curr) => acc + curr.balance, 0);

  const prompt = `
    Context: Elite Real Estate Advisor in Louisville, Kentucky.
    Scenario: Client selling $${current.value.toLocaleString()} home (3% rate) to buy $${newH.purchasePrice.toLocaleString()} (7% rate).
    Strategy: Using home equity to eliminate $${totalDebtPaid.toLocaleString()} in high-interest consumer debt.
    Monthly Impact: Total monthly outflow changes by $${Math.round(result.monthlySavings).toLocaleString()}.
    
    Task: Write a 120-word sophisticated, punchy strategy briefing. 
    Explain why "Lifestyle Cash Flow" beats "Interest Rate Pride." 
    Mention Louisville neighborhoods like Cherokee Park, Prospect, or the East End.
    Return only the analysis text.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Calculation complete. Let's discuss your custom equity allocation.";
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return "Strategic analysis ready. Let's schedule a call to review your custom debt-to-equity roadmap.";
  }
};
