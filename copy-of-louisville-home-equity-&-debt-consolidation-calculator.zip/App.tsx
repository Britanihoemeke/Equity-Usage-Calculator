
import React, { useState, useMemo } from 'react';
import { CurrentHome, NewHome, Debt, CalculationResult } from './types';
import NumberInput from './components/NumberInput';
import { getAIAnalysis } from './services/geminiService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const App: React.FC = () => {
  const [currentHome, setCurrentHome] = useState<CurrentHome>({
    value: 450000,
    mortgageBalance: 240000,
    interestRate: 3.25,
    termYears: 30,
    taxInsuranceEstimate: 480,
  });

  const [newHome, setNewHome] = useState<NewHome>({
    purchasePrice: 625000,
    interestRate: 6.875,
    termYears: 30,
    taxInsuranceEstimate: 680,
  });

  const [debts, setDebts] = useState<Debt[]>([
    { id: '1', name: 'Auto Loan', balance: 35000, monthlyPayment: 720, payOff: true },
    { id: '2', name: 'Credit Cards', balance: 15000, monthlyPayment: 450, payOff: true }
  ]);

  const [aiAnalysis, setAiAnalysis] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const calculateMortgage = (p: number, r: number, y: number) => {
    if (r === 0) return p / (y * 12);
    const mR = r / 100 / 12;
    const n = y * 12;
    return (p * mR * Math.pow(1 + mR, n)) / (Math.pow(1 + mR, n) - 1);
  };

  const results = useMemo((): CalculationResult => {
    const sellCost = currentHome.value * 0.06;
    const proceeds = currentHome.value - currentHome.mortgageBalance - sellCost;
    const totalDebtToPay = debts.filter(d => d.payOff).reduce((a, b) => a + b.balance, 0);
    const downPmt = Math.max(0, proceeds - totalDebtToPay);
    const loanAmt = Math.max(0, newHome.purchasePrice - downPmt);

    const currHousing = calculateMortgage(currentHome.mortgageBalance, currentHome.interestRate, currentHome.termYears) + currentHome.taxInsuranceEstimate;
    const currTotal = currHousing + debts.reduce((a, b) => a + b.monthlyPayment, 0);

    const newHousing = calculateMortgage(loanAmt, newHome.interestRate, newHome.termYears) + newHome.taxInsuranceEstimate;
    const newTotal = newHousing + debts.filter(d => !d.payOff).reduce((a, b) => a + b.monthlyPayment, 0);

    return {
      currentMonthlyTotal: currTotal,
      newMonthlyTotal: newTotal,
      monthlySavings: currTotal - newTotal,
      equityProceeds: proceeds,
      downPayment: downPmt,
      newLoanAmount: loanAmt,
      debtsPaidOff: totalDebtToPay
    };
  }, [currentHome, newHome, debts]);

  const handleAIRequest = async () => {
    setLoading(true);
    const res = await getAIAnalysis(currentHome, newHome, debts, results);
    setAiAnalysis(res);
    setLoading(false);
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 lg:p-12">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12 bg-white p-8 rounded-[2.5rem] custom-shadow border border-slate-100">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight leading-none mb-2 uppercase">Equity Unlocker</h1>
          <p className="text-blue-600 font-bold text-xs uppercase tracking-[0.3em]">Louisville Strategy Console</p>
        </div>
        <div className="flex gap-4">
          <button onClick={handleAIRequest} disabled={loading} className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black text-sm hover:bg-blue-600 transition-all shadow-xl disabled:opacity-50">
            {loading ? 'Crunching Strategy...' : '✨ Get AI Brief'}
          </button>
          <a href="tel:5020000000" className="bg-blue-50 text-blue-600 px-8 py-4 rounded-2xl font-black text-sm hover:bg-blue-100 transition-all">Schedule Call</a>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-4 space-y-8">
          <div className="bg-white p-8 rounded-[2.5rem] custom-shadow border border-slate-100">
            <h2 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-[10px] flex items-center justify-center font-bold">01</span>
              Current Home
            </h2>
            <NumberInput label="Home Value" value={currentHome.value} onChange={v => setCurrentHome({...currentHome, value: v})} prefix="$" />
            <NumberInput label="Balance" value={currentHome.mortgageBalance} onChange={v => setCurrentHome({...currentHome, mortgageBalance: v})} prefix="$" />
            <div className="flex gap-4">
              <NumberInput label="Rate" value={currentHome.interestRate} onChange={v => setCurrentHome({...currentHome, interestRate: v})} suffix="%" />
              <NumberInput label="Taxes (Mo)" value={currentHome.taxInsuranceEstimate} onChange={v => setCurrentHome({...currentHome, taxInsuranceEstimate: v})} prefix="$" />
            </div>
          </div>

          <div className="bg-white p-8 rounded-[2.5rem] custom-shadow border border-slate-100">
            <h2 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-[10px] flex items-center justify-center font-bold">02</span>
              New Home Goal
            </h2>
            <NumberInput label="Purchase Price" value={newHome.purchasePrice} onChange={v => setNewHome({...newHome, purchasePrice: v})} prefix="$" />
            <div className="flex gap-4">
              <NumberInput label="Target Rate" value={newHome.interestRate} onChange={v => setNewHome({...newHome, interestRate: v})} suffix="%" />
              <NumberInput label="Taxes (Mo)" value={newHome.taxInsuranceEstimate} onChange={v => setNewHome({...newHome, taxInsuranceEstimate: v})} prefix="$" />
            </div>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-blue-600 p-8 rounded-[2.5rem] text-white shadow-2xl shadow-blue-200">
              <p className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-2">Monthly Cash Saved</p>
              <h3 className="text-4xl font-black mb-1">${Math.round(results.monthlySavings).toLocaleString()}</h3>
              <p className="text-[10px] font-bold opacity-80 uppercase tracking-widest">Budget Efficiency</p>
            </div>
            <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-2xl">
              <p className="text-[10px] font-black uppercase tracking-widest opacity-40 mb-2">Total Debt Erased</p>
              <h3 className="text-4xl font-black mb-1">${Math.round(results.debtsPaidOff).toLocaleString()}</h3>
              <p className="text-[10px] font-bold opacity-40 uppercase tracking-widest">Liquidated Equity</p>
            </div>
            <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 custom-shadow">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Down Payment</p>
              <h3 className="text-4xl font-black text-slate-900 mb-1">${Math.round(results.downPayment).toLocaleString()}</h3>
              <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Proceeds Invested</p>
            </div>
          </div>

          <div className="bg-white p-10 rounded-[2.5rem] custom-shadow border border-slate-100">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-xl font-black text-slate-900">Debt Consolidation Dashboard</h2>
              <button onClick={() => setDebts([...debts, { id: Date.now().toString(), name: 'New Debt', balance: 0, monthlyPayment: 0, payOff: true }])} className="text-blue-600 font-black text-[10px] uppercase tracking-widest">+ Add Entry</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {debts.map(debt => (
                <div key={debt.id} className={`p-6 rounded-[2rem] border-2 transition-all ${debt.payOff ? 'bg-blue-50/30 border-blue-100' : 'bg-slate-50 border-slate-50'}`}>
                  <div className="flex justify-between mb-4">
                    <input className="bg-transparent font-black text-slate-800 text-sm outline-none w-3/4" value={debt.name} onChange={e => setDebts(debts.map(d => d.id === debt.id ? {...d, name: e.target.value} : d))} />
                    <button onClick={() => setDebts(debts.filter(d => d.id !== debt.id))} className="text-slate-300 hover:text-red-400 font-black">×</button>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <NumberInput label="Balance" value={debt.balance} onChange={v => setDebts(debts.map(d => d.id === debt.id ? {...d, balance: v} : d))} prefix="$" />
                    <NumberInput label="Monthly" value={debt.monthlyPayment} onChange={v => setDebts(debts.map(d => d.id === debt.id ? {...d, monthlyPayment: v} : d))} prefix="$" />
                  </div>
                  <button onClick={() => setDebts(debts.map(d => d.id === debt.id ? {...d, payOff: !d.payOff} : d))} className={`w-full py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${debt.payOff ? 'bg-blue-600 text-white' : 'bg-white text-slate-400 border border-slate-200'}`}>
                    {debt.payOff ? '✓ Strategic Pay-off' : 'Keep Pmt'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {aiAnalysis && (
            <div className="bg-slate-900 p-10 rounded-[3rem] text-white relative overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-700">
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-6">
                  <div className="bg-blue-600 p-2 rounded-xl text-white">
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                  </div>
                  <h3 className="text-xl font-black">AI Strategic Overview</h3>
                </div>
                <div className="text-slate-300 leading-relaxed font-medium text-lg italic border-l-4 border-blue-600 pl-6">
                  "{aiAnalysis}"
                </div>
              </div>
            </div>
          )}

          <div className="bg-white p-10 rounded-[2.5rem] custom-shadow border border-slate-100 h-[450px] flex flex-col">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-10">Monthly Outlay Comparison</h3>
            <div className="flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={[
                  { name: 'Current', Housing: Math.round(calculateMortgage(currentHome.mortgageBalance, currentHome.interestRate, currentHome.termYears) + currentHome.taxInsuranceEstimate), Debts: Math.round(debts.reduce((a, b) => a + b.monthlyPayment, 0)) },
                  { name: 'Strategy', Housing: Math.round(calculateMortgage(results.newLoanAmount, newHome.interestRate, newHome.termYears) + newHome.taxInsuranceEstimate), Debts: Math.round(debts.filter(d => !d.payOff).reduce((a, b) => a + b.monthlyPayment, 0)) }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 800}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} />
                  <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)'}} />
                  <Bar dataKey="Housing" stackId="a" fill="#3b82f6" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="Debts" stackId="a" fill="#e2e8f0" radius={[15, 15, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      <footer className="mt-20 py-12 border-t border-slate-100 text-center">
        <p className="text-slate-800 font-black mb-1">Louisville Home Strategy Group</p>
        <p className="text-[10px] text-slate-400 uppercase font-bold tracking-[0.3em]">Licensed Real Estate Advisory</p>
        <p className="text-[10px] text-slate-300 max-w-2xl mx-auto mt-6 italic">
          Disclaimer: This calculator is for educational purposes only. Interest rates, property taxes, and home valuations are estimates based on market trends and user input. Always consult with a licensed mortgage lender and tax professional before making real estate decisions.
        </p>
      </footer>
    </div>
  );
};

export default App;
